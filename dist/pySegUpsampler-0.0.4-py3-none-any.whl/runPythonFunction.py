#import SegmentationUpsampler.UpsampleMultiLabels as um

newMatrix = a
#newMatrix = um.upsample(multiLabelMatrix, sigma, targetVolume, scale, 
#                        spacing, iso, fillGaps, NB)
#np.save('multilabelTestShape.npy', multiLabelMatrix)
